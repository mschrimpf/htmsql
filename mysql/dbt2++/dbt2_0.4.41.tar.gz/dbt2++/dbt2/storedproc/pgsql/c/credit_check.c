/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2003-2006 Mark Wong & Open Source Development Labs, Inc.
 * Copyright (C) 2011 Dan R. K. Ports
 *
 * Based on Michael J. Cahill, "Serializable Isolation for Snapshot
 * Databases"
 */

#include <sys/types.h>
#include <unistd.h>
#include <postgres.h>
#include <fmgr.h>
#include <executor/spi.h> /* this should include most necessary APIs */
#include <executor/executor.h>  /* for GetAttributeByName() */
#include <funcapi.h> /* for returning set of rows in order_status */

#ifdef PG_MODULE_MAGIC
PG_MODULE_MAGIC;
#endif

/*
 * Credit Check transaction SQL Statement.
 */

#define CREDIT_CHECK_1 \
	"SELECT c_balance, c_credit_lim\n" \
	"FROM customer\n" \
	"WHERE c_id = %d AND c_d_id = %d AND c_w_id = %d"

#define CREDIT_CHECK_2 \
	"SELECT SUM(ol_amount)\n" \
	"FROM order_line, orders, new_order\n" \
	"WHERE ol_o_id = o_id AND ol_d_id = %d\n" \
	"AND ol_w_id = %d AND o_d_id = %d\n" \
	"AND o_w_id = %d AND o_c_id = %d\n" \
    "AND no_o_id = o_id AND no_d_id = %d\n" \
	"AND no_w_id = %d"

#define CREDIT_CHECK_3 \
	"UPDATE customer SET c_credit = '%s'\n" \
	"WHERE c_id = %d AND c_d_id = %d AND c_w_id = %d"


/* Prototypes to prevent potential gcc warnings. */
Datum credit_check(PG_FUNCTION_ARGS);

PG_FUNCTION_INFO_V1(credit_check);

Datum credit_check(PG_FUNCTION_ARGS)
{
	/* Input variables. */
	int32 w_id = PG_GETARG_INT32(0);
	int32 d_id = PG_GETARG_INT32(1);
	int32 c_id = PG_GETARG_INT32(2);

	TupleDesc tupdesc;
	SPITupleTable *tuptable;
	HeapTuple tuple;

	int c_balance = 0;
	int c_credit_lim = 0;
	int sum = 0;
	int ret;
	char query[256];
	char *buf;

	SPI_connect();

	sprintf(query, CREDIT_CHECK_1, c_id, d_id, w_id);
	elog(DEBUG1, "%s", query);
	ret = SPI_exec(query, 0);
	if (ret == SPI_OK_SELECT && SPI_processed > 0) {
		tupdesc = SPI_tuptable->tupdesc;
		tuptable = SPI_tuptable;
		tuple = tuptable->vals[0];

		buf = SPI_getvalue(tuple, tupdesc, 1);
		elog(DEBUG1, "c_balance = %s", buf);
		c_balance = atoi(buf);

		buf = SPI_getvalue(tuple, tupdesc, 2);
		elog(DEBUG1, "c_credit_lim = %s", buf);
		c_credit_lim = atoi(buf);
	} else {
		SPI_finish();
		PG_RETURN_INT32(-1);
	}

	sprintf(query, CREDIT_CHECK_2,
			d_id, w_id, d_id, w_id, c_id, d_id, w_id);
	elog(DEBUG1, "%s", query);
	ret = SPI_exec(query, 0);
	if (ret == SPI_OK_SELECT && SPI_processed > 0) {
		tupdesc = SPI_tuptable->tupdesc;
		tuptable = SPI_tuptable;
		tuple = tuptable->vals[0];

		buf = SPI_getvalue(tuple, tupdesc, 1);
		elog(DEBUG1, "sum = %s", buf);
		if (buf != NULL)
			sum = atoi(buf);
		else
			sum = 0;
	} else {
		SPI_finish();
		PG_RETURN_INT32(-1);
	}

	sprintf(query, CREDIT_CHECK_3,
			((c_balance + sum > c_credit_lim) ? "BC" : "GC"),
			c_id, d_id, w_id);
	elog(DEBUG1, "%s", query);
	ret = SPI_exec(query, 0);
	if (ret != SPI_OK_UPDATE) {
		SPI_finish();
		PG_RETURN_INT32(-1);
	}

	SPI_finish();
	PG_RETURN_INT32(0);
}
