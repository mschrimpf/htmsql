/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2002 Mark Wong & Open Source Development Labs, Inc.
 *
 * 13 May 2003
 */

#include <stdio.h>

#include "common.h"
#include "logging.h"
#include "libpq_delivery.h"

int execute_delivery(struct db_context_t *dbc, struct delivery_t *data)
{
	PGresult *res;
	char stmt[128];

	/* Start a transaction block. */
	res = PQexec(dbc->conn, "BEGIN");
        CHECK_FOR_ERROR(res, dbc);
	PQclear(res);

	/* Create the query and execute it. */
	sprintf(stmt, "SELECT deliver_1(%d, %d, %d)",
		data->w_id, data->o_carrier_id, data->d_id);
	res = PQexec(dbc->conn, stmt);
        CHECK_FOR_ERROR(res, dbc);
	PQclear(res);

	return OK;
}
