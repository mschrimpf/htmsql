#!/bin/sh

gnuplot data.blkread.input
gnuplot data.blkreadps.input
gnuplot data.blkwrtn.input
gnuplot data.blkwrtnps.input
gnuplot data.tps.input
gnuplot log.blkread.input
gnuplot log.blkreadps.input
gnuplot log.blkwrtn.input
gnuplot log.blkwrtnps.input
gnuplot log.tps.input
gnuplot temp.blkread.input
gnuplot temp.blkreadps.input
gnuplot temp.blkwrtn.input
gnuplot temp.blkwrtnps.input
gnuplot temp.tps.input
