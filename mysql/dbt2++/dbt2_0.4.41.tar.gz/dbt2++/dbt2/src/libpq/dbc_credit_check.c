/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2011 Dan R. K. Ports
 *
 * 28 Nov 2011
 */

#include <stdio.h>

#include "common.h"
#include "logging.h"
#include "libpq_credit_check.h"

int execute_credit_check(struct db_context_t *dbc, struct credit_check_t *data)
{
	PGresult *res;
	char stmt[128];

	/* Start a transaction block. */
	res = PQexec(dbc->conn, "BEGIN");
        CHECK_FOR_ERROR(res, dbc);
	PQclear(res);

	/* Create the query and execute it. */
	sprintf(stmt, "SELECT credit_check(%d, %d, %d)",
		data->w_id, data->d_id, data->c_id);
	res = PQexec(dbc->conn, stmt);
        CHECK_FOR_ERROR(res, dbc);
	PQclear(res);

	return OK;
}
