/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2002 Mark Wong & Open Source Development Labs, Inc.
 *
 * May 13 2003
 */

#ifndef _LIBPQ_COMMON_H_
#define _LIBPQ_COMMON_H_

#include <libpq-fe.h>
#include <string.h>

#include "transaction_data.h"

struct db_context_t {
	PGconn *conn;
};

int commit_transaction(struct db_context_t *dbc);
int _connect_to_db(struct db_context_t *dbc);
int _disconnect_from_db(struct db_context_t *dbc);
int _db_init(char *_dbname, char *_pghost, char *_pgport);
int rollback_transaction(struct db_context_t *dbc);

#define CHECK_FOR_ERROR(res, dbc)                                       \
    if (!res || (PQresultStatus(res) != PGRES_TUPLES_OK &&              \
                 PQresultStatus(res) != PGRES_COMMAND_OK)) {            \
        if (res &&                                                      \
            (PQresultErrorField(res, PG_DIAG_SQLSTATE) != NULL) &&      \
            ((strcmp(PQresultErrorField(res, PG_DIAG_SQLSTATE),          \
                       "40001") == 0) ||                                \
            (strcmp(PQresultErrorField(res, PG_DIAG_SQLSTATE), "40P01") == 0))) { \
            LOG_ERROR_MESSAGE("serialization rollback: %s",             \
                              PQerrorMessage(dbc->conn));               \
            PQclear(res);                                               \
            return ERROR_SERIALIZATION_FAILURE;                         \
        }                                                               \
        LOG_ERROR_MESSAGE("other rollback (%s): %s",                    \
                          PQresultErrorField(res, PG_DIAG_SQLSTATE),    \
                          PQerrorMessage(dbc->conn));                   \
        PQclear(res);                                                   \
        return ERROR;                                                \
    }

extern char dbname[32];
extern char pghost[32];
extern char pgport[32];

#endif /* _LIBPQ_COMMON_H_ */
