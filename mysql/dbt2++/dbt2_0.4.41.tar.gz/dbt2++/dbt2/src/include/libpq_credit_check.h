/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2011 Dan R. K. Ports
 *
 * 28 Nov 2011
 */

#ifndef _LIBPQ_CREDIT_CHECK_H_
#define _LIBPQ_CREDIT_CHECK_H_

#include "libpq_common.h"

int execute_credit_check(struct db_context_t *dbc, struct credit_check_t *data);

#endif /* _LIBPQ_CREDIT_CHECK_H_ */
