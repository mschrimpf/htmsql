/*
 * This file is released under the terms of the Artistic License.  Please see
 * the file LICENSE, included in this package, for details.
 *
 * Copyright (C) 2011 Dan R. K. Ports
 */

CREATE OR REPLACE FUNCTION credit_check (INTEGER, INTEGER, INTEGER)
RETURNS INTEGER AS
'$libdir/credit_check'
LANGUAGE C STRICT;
